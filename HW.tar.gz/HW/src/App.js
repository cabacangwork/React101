import React from 'react';
import { Component } from 'react';
import TodoList from './TodoList';
import './../public/css/styles.css'

class App extends Component {
  constructor() {
    super() 
    this.state = { 
      buttonEnable: true,  
      id: null,    
      mockData: [
        {      
          id: '1',      
          title: 'Buy Milk',      
          done: false,      
          date: new Date()    
        }, 
        {      
          id: '2',      
          title: 'Meeting with Ali',      
          done: false,      
          date: new Date()    
        }, 
        {      
          id: '3',      
          title: 'Tea break',      
          done: false,      
          date: new Date()    
        }, 
        {      
          id: '4',      
          title: 'Go for a run.',      
          done: false,      
          date: new Date()    
        }
      ]
    }
  }

  onButtonEnable = e => {
    this.setState({
      buttonEnable: false
    });
  }

  addItem = e => {
    console.log('Added');
    e.preventDefault();
    this.setState({    
      mockData: 
      [...this.state.mockData, 
        { 
          id: Date.now(),        
          title: event.target.item.value,        
          done: false,        
          date: new Date()    
        }
      ]  
    });
    e.target.item.value = '';
  }

  render() {
    return (
      <div className="content-wrapper">
        <TodoList 
          entries={this.state.mockData}
          buttonEnable={this.state.buttonEnable}
          addItem={this.addItem}
          onButtonEnable={this.onButtonEnable}
        />
      </div>
    )
  }

}

export default App;