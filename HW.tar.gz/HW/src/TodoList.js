import React from 'react';
import { Component } from 'react';
import './../public/css/styles.css'

class TodoList extends Component {

  render () {
    return (
      <div>
        <form onSubmit={this.props.addItem}>
          <input type="text" name="item" onChange={this.props.onButtonEnable}/>        
          <button disabled={this.props.buttonEnable}>Add</button>
        </form>
        <ul>
          {this.props.entries.map(item => (          
            <li key={item.id}>
              {item.title}
              <button>Delete</button>            
              <button>Edit</button>            
              <button>Complete</button>          
            </li>        
          ))}      
        </ul>
      </div>
    );
  }

}

export default TodoList;

{/* <button onClick={this.onDeleteHandle.bind(this, item.id)}>Delete</button>            
<button onClick={this.onEditHandle.bind(this, item.id, item.title)}>Edit</button>                 */}